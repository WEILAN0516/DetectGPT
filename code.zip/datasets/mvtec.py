import os
from torch.utils.data import Dataset
import cv2
import numpy as np
import torch
import torchvision.transforms as transforms
from PIL import Image


from .self_sup_tasks import patch_ex

# 宽度范围百分比的界限
WIDTH_BOUNDS_PCT = {'bottle':((0.03, 0.4), (0.03, 0.4)), 'cable':((0.05, 0.4), (0.05, 0.4)), 'capsule':((0.03, 0.15), (0.03, 0.4)), 
                    'hazelnut':((0.03, 0.35), (0.03, 0.35)), 'metal_nut':((0.03, 0.4), (0.03, 0.4)), 'pill':((0.03, 0.2), (0.03, 0.4)), 
                    'screw':((0.03, 0.12), (0.03, 0.12)), 'toothbrush':((0.03, 0.4), (0.03, 0.2)), 'transistor':((0.03, 0.4), (0.03, 0.4)), 
                    'zipper':((0.03, 0.4), (0.03, 0.2)), 
                    'carpet':((0.03, 0.4), (0.03, 0.4)), 'grid':((0.03, 0.4), (0.03, 0.4)), 
                    'leather':((0.03, 0.4), (0.03, 0.4)), 'tile':((0.03, 0.4), (0.03, 0.4)), 'wood':((0.03, 0.4), (0.03, 0.4))}

# 默认为2 后面没用到这玩意儿
# 应当从图像中提取的补丁（patches）数量
# 对于"screw"（螺丝）和"zipper"（拉链），由于它们的形状可能更复杂或更难以从背景中区分，所以设置了需要提取4个补丁
NUM_PATCHES = {'bottle':3, 'cable':3, 'capsule':3, 'hazelnut':3, 'metal_nut':3, 
               'pill':3, 'screw':4, 'toothbrush':3, 'transistor':3, 'zipper':4,
               'carpet':4, 'grid':4, 'leather':4, 'tile':4, 'wood':4}

# k, x0 pairs
# 为每个物体定义了逻辑回归模型的两个参数k和x0，这可能用于调整图像的某些特性，如亮度、对比度或在特定情境下的特征强度
# k控制曲线的陡峭程度，x0是曲线的中点 1/(1+e^-k*(x-x0))
INTENSITY_LOGISTIC_PARAMS = {'bottle':(1/12, 24), 'cable':(1/12, 24), 'capsule':(1/2, 4), 'hazelnut':(1/12, 24), 'metal_nut':(1/3, 7), 
            'pill':(1/3, 7), 'screw':(1, 3), 'toothbrush':(1/6, 15), 'transistor':(1/6, 15), 'zipper':(1/6, 15),
            'carpet':(1/3, 7), 'grid':(1/3, 7), 'leather':(1/3, 7), 'tile':(1/3, 7), 'wood':(1/6, 15)}

# 后面没用到这玩意儿 +1
# bottle is aligned but it's symmetric under rotation    瓶子是对齐的，但旋转时是对称的
# 列表包含那些不需要对齐的物体，可能因为这些物体具有某种对称性或者在视觉上对旋转不敏感
# 例如，'bottle'（瓶子）即便在不同角度下，其形状和特征在视觉上也保持相对稳定，因此可以认为是对齐不敏感的
UNALIGNED_OBJECTS = ['bottle', 'hazelnut', 'metal_nut', 'screw']

# brightness, threshold pairs
# 定义了背景的亮度和阈值对，可能用于背景分割或调整，以便更好地突出前景物体
BACKGROUND = {'bottle':(200, 60), 'screw':(200, 60), 'capsule':(200, 60), 'zipper':(200, 60), 
              'hazelnut':(20, 20), 'pill':(20, 20), 'toothbrush':(20, 20), 'metal_nut':(20, 20)}

OBJECTS = ['bottle', 'cable', 'capsule', 'hazelnut', 'metal_nut', 
            'pill', 'screw', 'toothbrush', 'transistor', 'zipper']
TEXTURES = ['carpet', 'grid', 'leather', 'tile', 'wood']

describles = {}
describles['bottle'] = "This is a photo of a bottle for anomaly detection, which should be round, without any damage, flaw, defect, scratch, hole or broken part."
describles['cable'] = "This is a photo of three cables for anomaly detection, they are green, blue and grey, which cannot be missed or swapped and should be without any damage, flaw, defect, scratch, hole or broken part."
describles['capsule'] = "This is a photo of a capsule for anomaly detection, which should be black and orange, with print '500', without any damage, flaw, defect, scratch, hole or broken part."
describles['carpet'] = "This is a photo of carpet for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."
describles['grid'] = "This is a photo of grid for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."
describles['hazelnut'] = "This is a photo of a hazelnut for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."
describles['leather'] = "This is a photo of leather for anomaly detection, which should be brown and without any damage, flaw, defect, scratch, hole or broken part."
describles['metal_nut'] = "This is a photo of a metal nut for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part, and shouldn't be fliped."
describles['pill'] = "This is a photo of a pill for anomaly detection, which should be white, with print 'FF' and red patterns, without any damage, flaw, defect, scratch, hole or broken part."
describles['screw'] = "This is a photo of a screw for anomaly detection, which tail should be sharp, and without any damage, flaw, defect, scratch, hole or broken part."
describles['tile'] = "This is a photo of tile for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."
describles['toothbrush'] = "This is a photo of a toothbrush for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."
describles['transistor'] = "This is a photo of a transistor for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."
describles['wood'] = "This is a photo of wood for anomaly detection, which should be brown with patterns, without any damage, flaw, defect, scratch, hole or broken part."
describles['zipper'] = "This is a photo of a zipper for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part."


class MVtecDataset(Dataset):
    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        # self.transform = transform
        # 定义一个图像变换，这里使用的是transforms.Resize来调整图像的大小到224x224，使用的插值方法是双三次插值(BICUBIC)
        self.transform = transforms.Resize(
                                (224, 224), interpolation=transforms.InterpolationMode.BICUBIC
                            )
        # 定义一个标准化转换，包括将图像转换为张量和对图像进行标准化处理。标准化使用的均值和标准差是预先定义好的，这些值可能是针对特定任务或数据集优化的
        self.norm_transform = transforms.Compose(
                            [
                                transforms.ToTensor(),
                                transforms.Normalize(
                                    mean=(0.48145466, 0.4578275, 0.40821073),
                                    std=(0.26862954, 0.26130258, 0.27577711),
                                ),
                            ]
                        )
        # 图片路径和相应变换后的图片
        self.paths = []
        self.x = []

        for root, dirs, files in os.walk(root_dir):
            for file in files:
                file_path = os.path.join(root, file)
                # 条件包括文件路径中必须包含"train"和"good"，且文件扩展名为'png'，这意味着只选择了作为正常（好的）样本的训练图像
                if "train" in file_path and "good" in file_path and 'png' in file:
                    self.paths.append(file_path)
                    self.x.append(self.transform(Image.open(file_path).convert('RGB')))

        # 通过在self.paths列表长度范围内生成一个随机整数来初始化
        self.prev_idx = np.random.randint(len(self.paths))

    def __len__(self):
        #     # 数据集中图像的总数
        return len(self.paths)

    def __getitem__(self, index):
        # 获取图像路径img_path，以及相应的经过初步变换的图像x（这里的x是在初始化时已经通过self.transform变换过的图像）。
        img_path, x = self.paths[index], self.x[index]
        # C:/Users/xxa/Desktop/AnomalyGPT-main/data/mvtec_anomaly_detection/zipper\train\good\239.png
        class_name = img_path.split('/')[-4]

        # 自监督任务参数    包括宽度边界、强度逻辑参数、补丁数量、最小物体百分比、最小重叠百分比等。对于纹理类别的图像，还会设置调整大小的边界
        self_sup_args={'width_bounds_pct': WIDTH_BOUNDS_PCT.get(class_name),
                    'intensity_logistic_params': INTENSITY_LOGISTIC_PARAMS.get(class_name),
                    'num_patches': 2, #if single_patch else NUM_PATCHES.get(class_name),
                    'min_object_pct': 0,
                    'min_overlap_pct': 0.25,
                    'gamma_params':(2, 0.05, 0.03),
                    'resize':True,
                    'shift':True, 
                    'same':False, 
                    'mode':cv2.NORMAL_CLONE,
                    'label_mode':'logistic-intensity',
                    'skip_background': BACKGROUND.get(class_name)}
        if class_name in TEXTURES:
            self_sup_args['resize_bounds'] = (.5, 2)

        # 现在的x是本来的图片 转化为numpy数组 赋值给origin
        x = np.asarray(x)
        origin = x


        # ？？？
        p = self.x[self.prev_idx]
        if self.transform is not None:
            p = self.transform(p)
        p = np.asarray(p)
        # 应用自监督参数，生成处理后的图像、掩码和中心点
        x, mask, centers = patch_ex(x, p, **self_sup_args)
        # 将生成的掩码转换为PyTorch张量，并且只保留掩码的第一个通道（如果掩码是多通道的），然后转换为浮点类型
        mask = torch.tensor(mask[None, ..., 0]).float()
        self.prev_idx = index

        # origin正常图像 x转换后异常图像
        origin = self.norm_transform(origin)
        x = self.norm_transform(x)

   
        if len(centers) > 0:
            position = []
            for center in centers:
                center_x = center[0] / 224
                center_y = center[1] / 224

                if center_x <= 1/3 and center_y <= 1/3:
                    position.append('top left')
                elif center_x <= 1/3 and center_y > 1/3 and center_y <= 2/3:
                    position.append('top')
                elif center_x <= 1/3 and center_y > 2/3:
                    position.append('top right')

                elif center_x <= 2/3 and center_y <= 1/3:
                    position.append('left')
                elif center_x <= 2/3 and center_y > 1/3 and center_y <= 2/3:
                    position.append('center')
                elif center_x <= 2/3 and center_y > 2/3:
                    position.append('right')

                elif center_y <= 1/3:
                    position.append('bottom left')
                elif center_y > 1/3 and center_y <= 2/3:
                    position.append('bottom')
                elif center_y > 2/3:
                    position.append('bottom right')

            conversation_normal = []
            conversation_normal.append({"from":"human","value": describles[class_name] + " Is there any anomaly in the image?"})
            conversation_normal.append({"from":"gpt","value":"No, there is no anomaly in the image."})
            


            conversation_abnormal = []
            conversation_abnormal.append({"from":"human","value": describles[class_name] + " Is there any anomaly in the image?"})


            # 只针对两个异常？？？
            if len(centers) > 1:
                abnormal_describe =  "Yes, there are " + str(len(centers)) + " anomalies in the image, they are at the "
                for i in range(len(centers)):
                    if i == 0:
                        # 对于第一个异常位置，直接添加到描述中
                        abnormal_describe += position[i]
                    # 如果有第二个位置且与第一个位置不同，则根据它是不是最后一个位置来决定是添加逗号还是“和”来连接
                    elif i == 1 and position[i] != position[i-1]:
                        if i != len(centers) - 1:
                            abnormal_describe += ", "
                            abnormal_describe += position[i]
                            # ? of the image
                        else:
                            abnormal_describe += " and " + position[i] + " of the image."
                    # 如果第二个位置与第一个位置相同，且只有这两个异常，则在末尾添加“of the image.”完成句子
                    elif i == 1 and position[i] == position[i-1]:
                        if i == len(centers) - 1:
                            abnormal_describe += " of the image."
            else:
                # 如果只检测到一个异常，则构建简单的描述，指出图像中异常的具体位置
                abnormal_describe = "Yes, there is an anomaly in the image, at the " + position[0] + " of the image."

            conversation_abnormal.append({"from":"gpt","value":abnormal_describe})

        else:
            print("no mask")
            conversation_normal = []
            conversation_normal.append({"from":"human","value":describles[class_name] + " Is there any anomaly in the image?"})
            conversation_normal.append({"from":"gpt","value":"No, there is no anomaly in the image."})

            conversation_abnormal = conversation_normal

        return origin, conversation_normal, x, conversation_abnormal, class_name, mask, img_path


    # 在使用PyTorch的DataLoader时定制批处理行为 将这些样本组合成一个批次
    def collate(self, instances):

        images = []
        texts = []
        class_names = []
        masks = []
        img_paths = []
        for instance in instances:
            images.append(instance[0])
            texts.append(instance[1])
            class_names.append(instance[4])
            masks.append(torch.zeros_like(instance[5]))
            img_paths.append(instance[6])

            images.append(instance[2])
            texts.append(instance[3])
            class_names.append(instance[4])
            masks.append(instance[5])
            img_paths.append(instance[6])

        return dict(
            images=images,
            texts=texts,
            class_names=class_names,
            masks=masks,
            img_paths=img_paths
        )