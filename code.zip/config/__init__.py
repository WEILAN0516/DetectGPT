import yaml

def load_model_config(model, mode):
    # load special config for each model        openllama_peft
    config_path = f'C:/Users/xxa/Desktop/AnomalyGPT-main/code/config/{model}.yaml'
    print(f'[!] load configuration from {config_path}')
    with open(config_path) as f:
        configuration = yaml.load(f, Loader=yaml.FullLoader)
        print(configuration)
        new_config = {}
        for key, value in configuration.items():
            print(key)
            if key in ['train', 'test', 'validation']:
                if mode == key:
                    new_config.update(value)#将配置文件中'train'部分的所有配置项合并到new_config中，覆盖任何现有的相同键
                    print(new_config)
            else:
                new_config[key] = value
                print(new_config)
        print(new_config)
        #之前： {'max_len': 512, 'penalty_alpha': 0.6, 'top_k': 10, 'top_p': 0.7, 'random_prefix_len': 5, 'sample_num': 2,
         # 'decoding_method': 'sampling', 'generate_len': 512, 'lora_r': 32, 'lora_alpha': 32, 'lora_dropout': 0.1,
         #'train': {'seed': 42, 'warmup_rate': 0.1, 'epochs': 50, 'max_length': 1024}}
        #之后： {'max_len': 512, 'penalty_alpha': 0.6, 'top_k': 10, 'top_p': 0.7, 'random_prefix_len': 5, 'sample_num': 2, 'decoding_method': 'sampling', 'generate_len': 512, 'lora_r': 32, 'lora_alpha': 32, 'lora_dropout': 0.1,
        # 'seed': 42, 'warmup_rate': 0.1, 'epochs': 50, 'max_length': 1024}
        configuration = new_config
    return configuration
# load_model_config('openllama_peft', 'train')




# 更新并附加model=openllama_peft  mode=train配置
def load_config(args):
    '''the configuration of each model can rewrite the base configuration'''
    # base config
    base_configuration = load_base_config()

    # load one model config
    configuration = load_model_config(args['model'], args['mode'])

    # update and append the special config for base config
    # 更新并附加基本配置的特殊配置
    base_configuration.update(configuration)
    configuration = base_configuration
    return configuration

def load_base_config():
    config_path = f'config/base.yaml'
    with open(config_path) as f:
        configuration = yaml.load(f, Loader=yaml.FullLoader)
    print(f'[!] load base configuration: {config_path}')
    return configuration