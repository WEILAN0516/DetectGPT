from header import *
import torch.nn.functional as F
from .ImageBind import *
from .ImageBind import data
from .modeling_llama import LlamaForCausalLM
from .AnomalyGPT_models import LinearLayer, PromptLearner
from transformers import StoppingCriteria, StoppingCriteriaList
from ..utils.loss import FocalLoss, BinaryDiceLoss
import kornia as K

import torch
from torch.nn.utils import rnn

# 改加
from peft import LoraConfig, TaskType, get_peft_model
from transformers import LlamaTokenizer



CLASS_NAMES = ['bottle', 'cable', 'capsule', 'carpet', 'grid', 'hazelnut', 'leather', 'metal nut', 'pill', 'screw', 'tile', 'toothbrush', 'transistor', 'wood', 'zipper', 'object',
               'candle', 'cashew', 'chewinggum', 'fryum', 'macaroni', 'pcb', 'pipe fryum']

prompt_normal = ['{}', 'flawless {}', 'perfect {}', 'unblemished {}', '{} without flaw', '{} without defect', '{} without damage']
prompt_abnormal = ['damaged {}', 'broken {}', '{} with flaw', '{} with defect', '{} with damage']

prompt_state = [prompt_normal, prompt_abnormal]
# 提示模板  模板将进一步填充 prompt_normal 或 prompt_abnormal 中的描述
prompt_templates = ['a photo of a {}.', 'a photo of the {}.']
# prompt_templates = [
#                         'a cropped photo of the {}.', 'a cropped photo of a {}.', 'a close-up photo of a {}.', 'a close-up photo of the {}.',
#                         'a bright photo of the {}.', 'a bright photo of a {}.', 'a dark photo of a {}.', 'a dark photo of the {}.',
#                         'a dark photo of the {}.', 'a dark photo of a {}.', 'a jpeg corrupted photo of a {}.', 'a jpeg corrupted photo of the {}.',
#                         'a blurry photo of the {}.', 'a blurry photo of a {}.', 'a photo of a {}.', 'a photo of the {}.',
#                         'a photo of the small {}.', 'a photo of a small {}.', 'a photo of the large {}.', 'a photo of a large {}.',
#                         'a photo of the {} for visual insprction.', 'a photo of a {} for visual insprction.',
#                         'a photo of the {} for anomaly detection.', 'a photo of a {} for anomaly detection.'
#                         ]

objs = ['bottle', 'cable', 'capsule', 'carpet', 'grid', 'hazelnut', 'leather', 'metal nut', 'pill', 'screw', 'tile', 'toothbrush', 'transistor', 'wood', 'zipper', 'object',
        'candle', 'cashew', 'chewinggum', 'fryum', 'macaroni', 'pcb', 'pipe fryum', 'macaroni1', 'macaroni2','pcb1', 'pcb2', 'pcb3', 'pcb4', 'capsules']

prompt_sentences = {}

for obj in objs:
    prompt_sentence_obj = []
    for i in range(len(prompt_state)):
        # 生成一个具体的短语，如 flawless bottle（完美的瓶子）或 damaged cable（损坏的电缆）
        prompted_state = [state.format(obj) for state in prompt_state[i]]
        prompted_sentence = []
        for s in prompted_state:
            for template in prompt_templates:
                # 例'a photo of a { flawless bottle}.', 'a photo of the { flawless bottle}.'
                prompted_sentence.append(template.format(s))
        prompted_sentence = data.load_and_transform_text(prompted_sentence, torch.cuda.current_device())
        prompt_sentence_obj.append(prompted_sentence)
    # prompt_sentences["bottle"] = [
    #     [tensor1, tensor2, tensor3, ..., tensorN],  # 正常状态描述的张量列表
    #     [tensor1', tensor2', tensor3', ..., tensorM']  # 异常状态描述的张量列表
    # ]
    # tensor1, tensor2, ...：这些是代表正常状态下描述句子的张量。
    # 例如，"a photo of a flawless bottle." 或 "a photo of the bottle without flaw."
    # 经过分词和其他必要的预处理后转换成张量。
    # tensor1', tensor2', ...：这些是代表异常状态下描述句子的张量。
    # 例如，"a photo of a damaged bottle." 或 "a photo of the bottle with defect."
    # 经过类似的处理转换成张量。
    prompt_sentences[obj] = prompt_sentence_obj



# 使用预定义的句子提示集合来编码文本，并从这些编码中获取特定对象的正常和异常状态下的文本特征
# 这个函数通过组合来自不同描述模板的文本特征，有效地利用了模型的能力来捕捉对象在不同状态下的语义特征，
# 这对于多模态学习和其他高级机器学习应用非常有用
def encode_text_with_prompt_ensemble(model, obj, device):

    global prompt_sentences
    normal_sentences = []
    abnormal_sentences = []
    for idx in range(len(obj)):
        # 每个对象名称中的下划线（如果有）被替换为空格，以匹配 prompt_sentences 字典的键
        sentence = prompt_sentences[obj[idx].replace('_', ' ')]
        normal_sentences.append(sentence[0])
        abnormal_sentences.append(sentence[1])
    # 使用 torch.cat 合并列表中的所有张量，并将合并后的张量移动到指定的计算设备
    normal_sentences = torch.cat(normal_sentences).to(device)
    abnormal_sentences = torch.cat(abnormal_sentences).to(device)

    # 模型被用来处理正常和异常句子的张量，并提取相应的嵌入向量。这里假设模型返回一个字典，包含不同模态的处理结果
    class_embeddings_normal = model({ModalityType.TEXT: normal_sentences})[ModalityType.TEXT][0]
    class_embeddings_abnormal = model({ModalityType.TEXT: abnormal_sentences})[ModalityType.TEXT][0]
    # class_embeddings /= class_embeddings.norm(dim=-1, keepdim=True)

    # 首先调整嵌入向量的形状以匹配对象数和每个对象的句子数，然后计算每个对象的句子嵌入的平均值，并对这些平均值进行归一化处理
    class_embeddings_normal = class_embeddings_normal.reshape((len(obj), len(prompt_templates) * len(prompt_normal), 1024))
    class_embeddings_normal = class_embeddings_normal.mean(dim=1, keepdim=True)
    class_embeddings_normal = class_embeddings_normal / class_embeddings_normal.norm(dim=-1, keepdim=True)

    class_embeddings_abnormal = class_embeddings_abnormal.reshape((len(obj), len(prompt_templates) * len(prompt_abnormal), 1024))
    class_embeddings_abnormal = class_embeddings_abnormal.mean(dim=1, keepdim=True)
    class_embeddings_abnormal = class_embeddings_abnormal / class_embeddings_abnormal.norm(dim=-1, keepdim=True)

    # 正常和异常状态下的嵌入向量被合并，形成一个包含每个对象正常和异常特征的单一特征集
    text_features = torch.cat([class_embeddings_normal, class_embeddings_abnormal], dim=1)

    return text_features


# StoppingCriteria 让模型在生成到第一个句号的时候，就停止生成，返回结果
class StoppingCriteriaSub(StoppingCriteria):
    # 在构造函数中，有两个参数：stops 是一个列表，用于定义哪些token（标记）的出现应该触发停止条件；
    # encounters 是一个整数，指定必须至少遇到多少次 stops 列表中的任意token才会触发停止
    # 构造函数还调用了父类的构造函数来进行必要的初始化
    def __init__(self, stops = [], encounters=1):
        super().__init__()
        self.stops = stops
        self.ENCOUNTERS = encounters

    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor):
        stop_count = 0
        for stop in self.stops:
            stop_count = (stop == input_ids[0]).sum().item()    # gpt 修改建议+=
        if stop_count >= self.ENCOUNTERS:
            return True
        return False


# 为对话生成任务等训练或评估模型预处理对话序列
# 此函数接受一个分词器和对话的结构化表示作为输入，并生成适合模型学习的输入和目标令牌序列
def build_one_instance(tokenizer, conversation):
    text_list = []
    # 对话中的总轮次数
    turn_num = len(conversation)
    input_ids, target_ids = [], []
    for i in range(turn_num):
        turn = conversation[i]
        role = turn['from']
        if i == 0: # the first human turn
            assert role == 'human'
            text = turn['value'] + '\n### Assistant:'
            # 分词器将文本转换为令牌ID，然后添加到input_ids中
            one_input_id = tokenizer(text, add_special_tokens=False).input_ids
            input_ids += one_input_id
            # 不对人工提示执行损失回归
            # 第一轮的目标ID对每个令牌设置为 -100，表明模型不应学习预测这些令牌（在掩码语言建模中常见）
            target_ids += [-100]*len(one_input_id) # do not perform loss regression on human prompt
        else:
            if role == 'human':
                # "### Assistant:" 为了提示接下来应由助手响应
                text = 'Human: ' + turn['value'] + '\n### Assistant:'
                one_input_id = tokenizer(text, add_special_tokens=False).input_ids
                input_ids += one_input_id
                target_ids += [-100]*len(one_input_id)
            elif role == 'gpt':
                # "###" 表示AI发言的结束，为后续的对话提供了分隔
                text = turn['value'] + '\n###'
                one_input_id = tokenizer(text, add_special_tokens=False).input_ids
                input_ids += one_input_id
                target_ids += one_input_id
            else:
                raise Exception('Wrong Role!!!')
        text_list.append(text)
        # 使用assert检查 input_ids 和 target_ids 的长度是否相同，确保每个输入令牌有一个对应的目标令牌。
        assert len(input_ids) == len(target_ids)
    return text_list, input_ids, target_ids

# 处理对话数据的批次，将其转换成适合于训练或评估模型的格式，如对话生成任务中使用
# 这个函数高效地将多个对话转换成填充的输入和目标令牌ID序列，并生成相应的注意力掩码1
def process_batch_instance(tokenizer, batch_of_conversations, max_tgt_len):
    # tokenizer：用于将文本转换为令牌ID的分词器对象。它还包含特殊令牌信息，如 pad_token_id
    # batch_of_conversations一个列表，每个元素是一个对话，格式为包含键 'from' 和 'value' 的字典列表。
    batch_input_ids, batch_target_ids = [], []
    for conversation in batch_of_conversations:
        _, one_input_ids, one_target_ids = build_one_instance(tokenizer, conversation)
        # 返回的令牌ID转换为 torch.LongTensor 并添加到相应的列表中。
        batch_input_ids.append(torch.LongTensor(one_input_ids))
        batch_target_ids.append(torch.LongTensor(one_target_ids))

    # rnn.pad_sequence：此函数来自 PyTorch 的 torch.nn.utils.rnn 模块，用于将序列填充到批次中最长序列的长度
    # batch_first=True 确保批次维度是第一维度
    # input_ids 的 padding_value 设置为 tokenizer.pad_token_id，以确保 填充值不影响模型的预测
    # target_ids 的 padding_value 设置为 -100，指示模型在训练时不应将这些令牌计入损失（在掩码语言建模任务中常见）
    input_ids = rnn.pad_sequence(batch_input_ids, batch_first=True, padding_value=tokenizer.pad_token_id)
    target_ids = rnn.pad_sequence(batch_target_ids, batch_first=True, padding_value=-100)

    assert input_ids.size() == target_ids.size()
    input_ids = input_ids[:,:max_tgt_len]
    target_ids = target_ids[:,:max_tgt_len]

    # 此掩码向模型指示哪些令牌是填充的，哪些是实际数据
    # 使用 ne（不等于）方法创建掩码，如果令牌不等于 pad_token_id（即应该被关注），则为1，否则为0
    attention_mask = input_ids.ne(tokenizer.pad_token_id)
    assert attention_mask.size() == input_ids.size()
    return input_ids, target_ids, attention_mask.long()

def find_first_file_in_directory(directory_path):
    try:
        file_list = os.listdir(directory_path)
        for item in file_list:
            item_path = os.path.join(directory_path, item)
            # 检查当前路径是否指向一个文件。如果是，立即返回该文件的路径。这意味着函数将返回目录中遇到的第一个文件路径
            if os.path.isfile(item_path):
                return item_path
        return None

    except OSError as e:
        print(f"Error while accessing directory: {e}")
        return None


PROMPT_START = '### Human: <Img>'
class OpenLLAMAPEFTModel(nn.Module):

    '''LoRA for LLaMa model'''

    def __init__(self, **args):
        super(OpenLLAMAPEFTModel, self).__init__()
        self.args = args
        imagebind_ckpt_path = args['imagebind_ckpt_path']
        vicuna_ckpt_path = args['vicuna_ckpt_path']
        max_tgt_len = args['max_tgt_len']
        stage = args['stage']

        print (f'Initializing visual encoder from {imagebind_ckpt_path} ...')

        # 视觉编码器：使用来自 imagebind_ckpt_path 的预训练权重初始化视觉编码器，此编码器用于从图像中提取特征
        # ImageBindModel, 1024
        self.visual_encoder, self.visual_hidden_size = imagebind_model.imagebind_huge(args)
        imagebind_ckpt = torch.load(imagebind_ckpt_path, map_location=torch.device('cuda'))#cpu
        self.visual_encoder.load_state_dict(imagebind_ckpt, strict=True)

        # 迭代计数器：iter 用于追踪训练过程中的迭代次数
        self.iter = 0

        # PromptLearner 用于从视觉特征中学习生成提示
        self.image_decoder = LinearLayer(1280, 1024, 4)

        # PromptLearner 用于从视觉特征中学习生成提示
        self.prompt_learner = PromptLearner(1, 4096)

        # 使用焦点损失（FocalLoss）和二值Dice损失（BinaryDiceLoss）来优化模型对复杂或不平衡数据的处理
        self.loss_focal = FocalLoss()
        self.loss_dice = BinaryDiceLoss()


        # free vision encoder
        # 参数冻结：为了防止在训练过程中改变视觉编码器的预训练权重，将其所有参数的 requires_grad 设置为 False
        # 设为评估模式：确保视觉编码器在推理模式下运行，不受训练过程中的批量规范化或丢弃层影响
        for name, param in self.visual_encoder.named_parameters():
            param.requires_grad = False
        self.visual_encoder.eval()
        print ('Visual encoder initialized.')

        # 将要初始化语言解码器，该解码器用于处理从视觉编码器得到的特征以生成语言输出
        print (f'Initializing language decoder from {vicuna_ckpt_path} ...')
        
        # add the lora module Low-Rank Adaptation
        peft_config = LoraConfig(
            # task_type：设置任务类型，这里是因果语言模型（Causal Language Model）
            task_type=TaskType.CAUSAL_LM,
            # inference_mode：设置是否为推理模式
            inference_mode=False,
            # r：LoRA的秩，控制低秩矩阵的大小
            r=self.args['lora_r'],
            # lora_alpha：LoRA的缩放系数
            lora_alpha=self.args['lora_alpha'],
            # lora_dropout：LoRA层中使用的dropout比率。
            lora_dropout=self.args['lora_dropout'],
            # target_modules：指定需要添加LoRA适配的模块，常见于Transformer架构中的q, k, v, o投影层
            target_modules=['q_proj', 'k_proj', 'v_proj', 'o_proj']
        )

        # 加载预训练模型：从 vicuna_ckpt_path 加载LLaMa模型，这是一个因果语言模型
        self.llama_model = LlamaForCausalLM.from_pretrained(vicuna_ckpt_path)
        # 应用LoRA适配：使用 get_peft_model 函数将LoRA配置应用到加载的模型上
        self.llama_model = get_peft_model(self.llama_model, peft_config)
        # 打印可训练参数：输出模型中可训练参数的详情，以便了解LoRA调整的影响
        self.llama_model.print_trainable_parameters()

        # 加载分词器：从同一个预训练路径加载LLaMa的分词器
        self.llama_tokenizer = LlamaTokenizer.from_pretrained(vicuna_ckpt_path, use_fast=False)
        # 设置填充令牌：将结束符（eos_token）用作填充令牌，这在某些语言生成任务中是常见的做法
        self.llama_tokenizer.pad_token = self.llama_tokenizer.eos_token
        # 填充方式：设置填充应用于序列的右侧
        self.llama_tokenizer.padding_side = "right"
        print ('Language decoder initialized.')

        # 定义线性层：这个线性层用于将视觉编码器的输出映射到语言模型的隐藏层大小，以便将视觉特征与文本特征有效地结合
        self.llama_proj = nn.Linear(
            self.visual_hidden_size, self.llama_model.config.hidden_size
        )

        self.max_tgt_len = max_tgt_len
        self.device = torch.cuda.current_device()


    def rot90_img(self,x,k):
        # x：输入的图像张量，通常是一个形状为 [B, C, H, W] 的四维张量，
        # 其中 B 是批次大小，C 是通道数，H 是图像高度，W 是图像宽度
        # k：整数，表示图像需要旋转90度的次数（0, 1, 2, 3）。k 的值决定了图像将被旋转的总角度（即 k * 90 度）
        # k is 0,1,2,3
        degreesarr = [0., 90., 180., 270., 360]
        # 根据 k 的值从 degreesarr 中选取相应的角度
        # 将选取的角度转换成一个张量，并确保这个张量的数据类型与模型使用的数据类型相同，并将其移到模型所在的设备上（例如GPU）
        degrees = torch.tensor(degreesarr[k]).to(self.llama_model.dtype).to(self.device)
        # padding_mode='reflection' 指定在旋转过程中超出原始图像边界的填充模式为反射填充，这有助于保持图像边缘的视觉连续性
        x = K.geometry.transform.rotate(x, angle = degrees, padding_mode='reflection')
        return x


# 视频编码函数，旨在处理视频路径列表，通过模型转换这些视频为可用于下游任务的嵌入表示
# 这个函数使用了预定义的视觉编码器和投影层，同时管理设备和数据类型转换，确保视频数据正确处理
    def encode_video(self, video_paths):
        inputs = {ModalityType.VISION: data.load_and_transform_video_data(video_paths, self.device)}
        # convert into visual dtype
        # 将输入数据的数据类型转换为与模型当前使用的数据类型（self.llama_model.dtype）相匹配，确保数据类型一致性
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            # video_embeds 从编码器输出中提取视觉模态的嵌入，这通常是批次大小 (bsz) 乘以嵌入维度（这里是 1024）
            video_embeds = embeddings[ModalityType.VISION][0] # bsz x 1024

        # 投影：使用 self.llama_proj 将视频嵌入从视觉模型的维度映射到LLaMa模型的维度空间
        # unsqueeze(1) 增加一个维度，这通常用于满足特定模型输入要求，如序列长度维度
        inputs_llama = self.llama_proj(video_embeds).unsqueeze(1) # bsz x 1 x llama_size
        # 注意力掩码：创建一个全为1的张量，形状与 inputs_llama 除最后一个维度外相同，这表示所有输入元素都应被模型注意
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama

    def encode_audio(self, audio_paths):
        inputs = {ModalityType.AUDIO: data.load_and_transform_audio_data(audio_paths, self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            audio_embeds = embeddings[ModalityType.AUDIO][0] # bsz x 1024
        inputs_llama = self.llama_proj(audio_embeds).unsqueeze(1) # bsz x 1 x llama_size
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama

    def encode_thermal(self, thermal_paths):
        inputs = {ModalityType.THERMAL: data.load_and_transform_thermal_data(thermal_paths, self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            image_embeds = embeddings['thermal'][0] # bsz x 1024
        inputs_llama = self.llama_proj(image_embeds).unsqueeze(1) # bsz x 1 x llama_size
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama


    # 处理图像路径列表，使用预训练的视觉编码器提取高级嵌入和更精细的图像块级特征
    # 此方法不仅将图像数据转换为模型可用的格式，还通过投影将这些图像特征整合到与语言模型兼容的格式中
    def encode_image(self, image_paths):
        inputs = {ModalityType.VISION: data.load_and_transform_vision_data(image_paths, self.device)}
        # convert into visual dtype
        # 确保所有加载的数据转换为模型使用的数据类型（dtype）
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}

        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            # 视觉编码器处理输入图像并返回嵌入
            # image_embeds 包含整体图像表示，patch_features 包含在每个图像不同位置提取的更细粒度特征
            image_embeds = embeddings['vision'][0] # bsz x 1024
            patch_features = embeddings['vision'][1] # bsz x h*w x 1280
        # 图像块解码：image_decoder（线性层）处理图像块特征，产生更适合进一步处理或与语言模型集成的表示
        patch_tokens = self.image_decoder(patch_features) # bsz x h*w x 1024
        # 投影：使用线性变换（self.llama_proj）将整体图像嵌入投影到LLaMa模型的维度空间
        # unsqueeze(1) 添加一个单例维度，使张量形状适用于后续的序列处理模型操作
        inputs_llama = self.llama_proj(image_embeds).unsqueeze(1) # bsz x 1 x llama_size
        # 创建一个全为1的张量，形状与 inputs_llama 除最后一个维度外相同，表明模型应注意所有位置
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama, patch_tokens
    
    def encode_image_for_web_demo(self, image_paths):
        inputs = {ModalityType.VISION: data.load_and_transform_vision_data_for_web_demo(image_paths, self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            image_embeds = embeddings['vision'][0] # bsz x 1024
            patch_features = embeddings['vision'][1] # bsz x h*w x 1280
        patch_tokens = self.image_decoder(patch_features) # bsz x h*w x 1024

        inputs_llama = self.llama_proj(image_embeds).unsqueeze(1) # bsz x 1 x llama_size
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama, patch_tokens
    
    def encode_image_for_one_shot(self, image_paths):
        inputs = {ModalityType.VISION: data.load_and_transform_vision_data(image_paths, self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            patch_features = embeddings['vision'][1] # bsz x h*w x 1280
            for i in range(len(patch_features)):
                # 维度调整：对每个图像块特征的张量进行转置操作，以适应后续处理的需要
                # 这里的 transpose(0, 1) 是为了调整维度，使其更符合特定的处理流程或模型输入要求
                patch_features[i] = patch_features[i].transpose(0, 1)[:, 1:, :]

        return patch_features
    
    def encode_image_for_one_shot_from_tensor(self, image_tensors):
        if not isinstance(image_tensors, list):
            image_tensors = [image_tensors]
        # 如果输入不是列表形式，将其转换为列表。这样做是为了统一处理单个图像和多个图像的情况
        # 使用 torch.stack 将图像张量列表沿新的批次维度堆叠，然后将堆叠后的张量移动到指定的设备（如GPU）
        inputs = {ModalityType.VISION: torch.stack(image_tensors, dim=0).to(self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            patch_features = embeddings['vision'][1] # bsz x h*w x 1280
            for i in range(len(patch_features)):
                patch_features[i] = patch_features[i].transpose(0, 1)[:, 1:, :]

        return patch_features


    # 处理图像路径列表，通过对图像进行旋转增强来增强单次学习的数据集
    # 此方法不仅转换图像数据以适应模型，还通过旋转操作生成多种视觉角度，以便提取更广泛的图像特征
    # 这种方法特别适合于需要从视觉数据中提取丰富特征以进行细致分析或单次学习的任务
    def encode_image_for_one_shot_with_aug(self, image_paths):
        image_tensors = data.load_and_transform_vision_data(image_paths, self.device).to(self.llama_model.dtype)

        # 定义存储张量：初始化一个用于存储旋转后图像的张量，形状为四个不同角度的旋转图像，每个角度包括整个批次的图像
        B,C,H,W = image_tensors.shape
        # print(B,C,H,W)
        rotated_images = torch.zeros((4, B, C, H, W)).to(self.llama_model.dtype).to(self.device)

        for j, degree in enumerate([0, 1, 2, 3]):
            rotated_img = self.rot90_img(image_tensors, degree)
            # 存储旋转后的图像
            rotated_images[j] = rotated_img

        # 数据重组：将四种旋转的图像数据重排列，使得可以将它们视为一个扩展的批次处理，便于后续的特征提取
        image_tensors = rotated_images.transpose(0,1).reshape(B * 4, C, H, W)

        inputs = {ModalityType.VISION: image_tensors}
        # convert into visual dtype
        inputs = {key: inputs[key] for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            patch_features = embeddings['vision'][1] # bsz x h*w x 1280
            for i in range(len(patch_features)):
                patch_features[i] = patch_features[i].transpose(0, 1)[:, 1:, :].reshape(B,4,256,1280).reshape(B, 4 * 256, 1280)

        return patch_features
    
    def encode_image_from_tensor(self, image_tensors):
        # 如果输入不是列表形式，将其转换为列表。这样做是为了统一处理单个图像和多个图像的情况
        # 使用 torch.stack 将图像张量列表沿新的批次维度堆叠，然后将堆叠后的张量移动到指定的设备（如GPU）
        if not isinstance(image_tensors, list):
            image_tensors = [image_tensors]
        inputs = {ModalityType.VISION: torch.stack(image_tensors, dim=0).to(self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            image_embeds = embeddings['vision'][0] # bsz x 1024
            patch_features = embeddings['vision'][1] # bsz x h*w x 1024
        patch_tokens = self.image_decoder(patch_features)


        inputs_llama = self.llama_proj(image_embeds).unsqueeze(1) # bsz x 1 x llama_size
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama, patch_tokens

    # 专为从已转换为张量的图像数据中提取整体图像嵌入而设计，不涉及提取具体的图像块级特征
    # 这个方法通过一个预训练的视觉编码器提取图像的高级表示，然后将这些表示投影到与语言模型兼容的空间中
    # 这种方法适用于需要图像整体信息而非细节信息的应用场景，如图像分类或整体图像描述生成
    def encode_image_from_tensor_no_patch(self, image_tensors):
        if not isinstance(image_tensors, list):
            image_tensors = [image_tensors]
        inputs = {ModalityType.VISION: torch.stack(image_tensors, dim=0).to(self.device)}
        # convert into visual dtype
        inputs = {key: inputs[key].to(self.llama_model.dtype) for key in inputs}
        with torch.no_grad():
            embeddings = self.visual_encoder(inputs)
            image_embeds = embeddings['vision'][0] # bsz x 1024

        # 使用 self.llama_proj（一个线性层）将图像嵌入投影到LLaMa模型的维度空间
        # unsqueeze(1) 添加一个单例维度，使得投影后的嵌入形状适合作为序列处理模型的输入
        inputs_llama = self.llama_proj(image_embeds).unsqueeze(1) # bsz x 1 x llama_size

        # 创建一个全为1的张量，形状与 inputs_llama 除最后一个维度外相同，表明模型应注意所有位置
        # 将掩码张量移动到适当的设备上
        atts_llama = torch.ones(inputs_llama.size()[:-1], dtype=torch.long).to(self.device) # bsz x 1
        return inputs_llama, atts_llama


    # prompt_wrap 方法设计用于结合图像嵌入和文本输入，生成适用于多模态任务的完整输入序列
    # 此方法通过将图像嵌入与特定的文本提示（如开始符、图像标志符等）结合，创建了一个适合LLaMa模型或类似模型处理的结构化输入
    # 这种方法非常适合那些需要理解和生成基于图像内容的文本描述的应用，例如图像描述生成或增强现实中的文本交互
    def prompt_wrap(self, img_embeds, input_ids, target_ids, attention_mask, anomaly_embedding = None):
        '''
            input_ids, target_ids, attention_mask: bsz x s2
        '''
        input_ids = input_ids.to(self.device) # bsz x s2
        target_ids = target_ids.to(self.device) # bsz x s2
        attention_mask = attention_mask.to(self.device) # bsz x s2

        batch_size = img_embeds.shape[0]
        p_before = PROMPT_START
        # 使用模型的分词器将文本转换为令牌，并获取这些令牌的嵌入
        p_before_tokens = self.llama_tokenizer(p_before, 
            return_tensors="pt", add_special_tokens=False).to(self.device)
        # peft model need deeper call
        # 获取 p_before_tokens 的嵌入表示，并将其扩展到整个批次，以匹配批次中每个实例的尺寸
        p_before_embeds = self.llama_model.model.model.embed_tokens(p_before_tokens.input_ids).expand(batch_size, -1, -1) # bsz x s1 x embed_dim

        # 构建中间和图像后文本嵌入：
        # p_middle 定义了图像和后续文本之间的分隔符。
        # 为分隔符获取嵌入，以便在图像嵌入后插入。
        p_middle = '</Img> '
        p_middle_tokens = self.llama_tokenizer(p_middle, 
            return_tensors="pt", add_special_tokens=False).to(self.device)
        # peft model need deeper call
        # 获取中间提示的嵌入，并扩展到整个批次
        p_middle_embeds = self.llama_model.model.model.embed_tokens(p_middle_tokens.input_ids).expand(batch_size, -1, -1) # bsz x s1 x embed_dim

        # 将主输入 input_ids 的令牌嵌入获取并扩展，以匹配批次大小和维度
        p_after_embeds = self.llama_model.model.model.embed_tokens(input_ids).expand(batch_size, -1, -1) # bsz x s2 x embed_dim
        # 创建一个包含序列开始符（BOS）的张量，初始化为全1，然后乘以开始符的令牌ID
        bos = torch.ones([batch_size, 1],
                         dtype=p_before_tokens.input_ids.dtype,
                         device=p_before_tokens.input_ids.device) * self.llama_tokenizer.bos_token_id # bsz x 1
        # 获取开始符的嵌入表示
        bos_embeds = self.llama_model.model.model.embed_tokens(bos) # bsz x 1 x embed_dim

        

        if anomaly_embedding != None:
            # 如果提供了异常嵌入，则将其与其他嵌入一起合并，创建完整的输入序列
            inputs_embeds = torch.cat([bos_embeds, p_before_embeds, img_embeds, p_middle_embeds, anomaly_embedding, p_after_embeds], dim=1) # bsz x (1+s1+1+s2) x embed_dim
            # create targets
            empty_targets = (
                torch.ones([batch_size, 1+p_before_embeds.size()[1]+1+p_middle_embeds.size()[1] + anomaly_embedding.size()[1]], # 1 (bos) + s1 + 1 (image vector)
                        dtype=torch.long).to(self.device).fill_(-100)  
            ) # bsz x (1 + s1 + 1)
            targets = torch.cat([empty_targets, target_ids], dim=1) # bsz x (1 + s1 + 1 + s2)
            assert inputs_embeds.size()[1] == targets.size()[1]

            atts_prefix = torch.ones([batch_size, 1+p_before_embeds.size()[1]+1+p_middle_embeds.size()[1] + anomaly_embedding.size()[1]], dtype=torch.long).to(self.device) # bsz x (1 + s1 +1)
            attention_mask = torch.cat([atts_prefix, attention_mask], dim=1)
            assert attention_mask.size() == targets.size() # bsz x (1 + s1 + 1 + s2)
            # 返回处理后的输入嵌入、目标标签和注意力掩码
            return inputs_embeds, targets, attention_mask 
        else:
            inputs_embeds = torch.cat([bos_embeds, p_before_embeds, img_embeds, p_middle_embeds, p_after_embeds], dim=1) # bsz x (1+s1+1+s2) x embed_dim
            # create targets
            empty_targets = (
                torch.ones([batch_size, 1+p_before_embeds.size()[1]+1+p_middle_embeds.size()[1]], # 1 (bos) + s1 + 1 (image vector)
                        dtype=torch.long).to(self.device).fill_(-100)  
            ) # bsz x (1 + s1 + 1)
            targets = torch.cat([empty_targets, target_ids], dim=1) # bsz x (1 + s1 + 1 + s2)
            assert inputs_embeds.size()[1] == targets.size()[1]

            atts_prefix = torch.ones([batch_size, 1+p_before_embeds.size()[1]+1+p_middle_embeds.size()[1]], dtype=torch.long).to(self.device) # bsz x (1 + s1 +1)
            attention_mask = torch.cat([atts_prefix, attention_mask], dim=1)
            assert attention_mask.size() == targets.size() # bsz x (1 + s1 + 1 + s2)
            return inputs_embeds, targets, attention_mask 

    # 图像嵌入、文本编码、异常检测和映射生成
    def forward(self, inputs):

        if 'masks' in inputs:

            image_paths = inputs['images']
            img_embeds, _, patch_tokens = self.encode_image_from_tensor(image_paths)
            # print(img_embeds.shape)
            # print(patch_tokens.shape)
            class_name = inputs['class_names']

            loss_pixel = 0
            feats_text_tensor = encode_text_with_prompt_ensemble(self.visual_encoder, class_name, self.device)

            # 初始化一个空列表 anomaly_maps 来存储每层生成的异常映射
            # 遍历每一层的图像块令牌，对每一层进行归一化处理，然后通过与文本特征张量的点积计算异常映射
            anomaly_maps = []
            for layer in range(len(patch_tokens)):
                patch_tokens[layer] = patch_tokens[layer] / patch_tokens[layer].norm(dim=-1, keepdim=True)
                # 计算当前层的图像块令牌和转置后的文本特征张量的点积，生成异常映射
                # 这个操作基于假设异常区域的图像块特征与文本描述存在较高的相似性
                # @ 运算符用于执行两个数组或张量的矩阵乘法
                anomaly_map = (100.0 * patch_tokens[layer] @ feats_text_tensor.transpose(-2,-1))

                # 提取异常映射的维度，其中 B 是批次大小，L 是特征长度，C 是通道数
                B, L, C = anomaly_map.shape
                # 计算可能的高度 H。这里假设图像块在空间上是平方排列的，因此通过对 L 开平方根得到每边的长度
                H = int(np.sqrt(L))
                # 使用 F.interpolate 对异常映射进行上采样，调整到特定的尺寸（这里是224x224），以适应特定的处理或显示需求
                anomaly_map = F.interpolate(anomaly_map.permute(0, 2, 1).view(B, 2, H, H),
                                            size=224, mode='bilinear', align_corners=True)
                # 对异常映射应用 softmax 函数进行归一化，然后将处理后的映射添加到 anomaly_maps 列表中
                anomaly_map = torch.softmax(anomaly_map, dim=1)
                anomaly_maps.append(anomaly_map)           

            # 从 inputs 字典中提取真实的掩码数据（masks），这些掩码用于指示图像中的异常区域
            # 使用 torch.stack 将掩码列表转换为一个张量，并将其移动到模型运行的设备上
            # 通过 squeeze 方法移除单维度条目，通常是为了保持数据的维度一致性
            # 将掩码二值化，设置阈值为0.3，大于0.3的值设为1（表示异常区域），小于或等于0.3的值设为0（表示正常区域）
            gt = inputs['masks']
            gt = torch.stack(gt, dim=0).to(self.device)
            gt = gt.squeeze()
            gt[gt > 0.3], gt[gt <= 0.3] = 1, 0

            # 遍历所有异常映射，对每一个映射计算焦点损失（loss_focal）和Dice损失（loss_dice）
            # 焦点损失用于处理类不平衡问题，Dice损失用于衡量预测区域与真实区域的相似度
            # 将每次循环计算得到的损失累加到 loss_pixel 变量中
            for num in range(len(anomaly_maps)):
                f_loss = self.loss_focal(anomaly_maps[num], gt)
                d_loss = self.loss_dice(anomaly_maps[num][:, 1, :, :], gt)
                loss_pixel = loss_pixel + f_loss + d_loss
            # 再次遍历所有异常映射，选择每个映射的第二个通道（一般代表预测为异常的概率）作为最终的异常映射
            for num in range(len(anomaly_maps)):
                anomaly_maps[num] = anomaly_maps[num][:,1,:,:]

            # 使用 torch.stack 将所有调整后的异常映射堆叠在一起，然后计算它们的平均值
            # 使用 mean 函数沿着堆叠的维度（dim=0）计算平均值，以获取所有图像的平均异常映射
            # 通过 unsqueeze 在维度1处添加一个新的维度，以便该映射可以与其他需要相同维度的数据一起使用
            anomaly_map_all = torch.mean(torch.stack(anomaly_maps, dim=0), dim=0).unsqueeze(1)
        
            if random.randint(0,1) == 0 and len(inputs['img_paths']) == len(image_paths):

                normal_paths = []
                # 遍历 inputs['img_paths'] 中的每个路径，根据路径中的关键词来确定对应的正常状态图像路径
                # 如果路径不包含 'all_anomalygpt' 且包含 'visa'，
                # 则将路径中的 'Anomaly' 替换为 'Normal'，然后查找该目录下的第一个文件作为正常图像路径
                # 如果不满足上述条件，将路径中的 'test' 替换为 'train'，并查找特定子目录下的第一个 'good' 图像文件
                for path in inputs['img_paths']:
                    if 'all_anomalygpt' not in path and 'visa' in path.lower():
                        normal_path = path.replace('Anomaly', 'Normal')
                        normal_path = find_first_file_in_directory("/".join(normal_path.split('/')[:-1]))
                    else:
                        normal_path = path.replace('test', 'train')
                        normal_path = find_first_file_in_directory("/".join(normal_path.split('/')[:-2])+'/good')
                    normal_paths.append(normal_path)

                print(normal_paths)

                # 对异常和正常图像进行特征编码
                # 对编码后的图像块特征进行形状调整，以计算查询图像和正常图像之间的余弦相似度
                # 提取每一对图像之间的最大相似度，并存储结果
                query_patch_tokens = self.encode_image_for_one_shot_from_tensor(image_paths)
                normal_patch_tokens = self.encode_image_for_one_shot_with_aug(normal_paths)
                sims = []
                B = len(image_paths)

                for i in range(len(query_patch_tokens)):
                    print(query_patch_tokens[i].shape)
                    query_patch_tokens_reshaped = query_patch_tokens[i].view(B,256,1,1280)
                    normal_tokens_reshaped = normal_patch_tokens[i].reshape(B,1,-1,1280)
                    cosine_similarity_matrix = F.cosine_similarity(query_patch_tokens_reshaped, normal_tokens_reshaped, dim=-1)
                    sim_max, _ = torch.max(cosine_similarity_matrix, dim=-1)
                    sims.append(sim_max)

                # 计算所有相似度的均值，然后调整形状和尺寸以匹配目标尺寸（例如224x224）
                # 最后，通过从1减去相似度得分来计算异常映射，这样做可以突出显示异常区域，其中相似度低表示高度异常
                sim = torch.mean(torch.stack(sims,dim=0), dim=0).reshape(B,1,16,16)
                sim = F.interpolate(sim,size=224, mode='bilinear', align_corners=True)
                anomaly_map_all = 1 - sim # (anomaly_map_all + 1 - sim) / 2
            anomaly_map_prompts = self.prompt_learner(anomaly_map_all)

            # img_embeds = img_embeds + anomaly_map_prompts
            # 准备输出文本的输入ID、目标ID和注意力掩码，使用process_batch_instance函数对输出文本进行处理
            output_texts = inputs['texts']
            input_ids, target_ids, attention_mask = process_batch_instance(self.llama_tokenizer, output_texts, self.max_tgt_len)

            # 使用prompt_wrap方法，将图像嵌入、输入ID、目标ID和注意力掩码包装成适合LLaMA模型输入的格式
            inputs_embeds, targets, attention_mask = self.prompt_wrap(img_embeds, input_ids, target_ids, attention_mask, anomaly_map_prompts)
            # 将处理后的输入传递给LLaMA模型进行推理，其中包括嵌入的输入、注意力掩码和目标标签，以获取模型输出
            outputs = self.llama_model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                return_dict=True,
                labels=targets,
            )
            loss = outputs.loss

            # loss_l2 = torch.norm(anomaly_map_prompts / 2 , p=2)
            # loss_l2 = nn.MSELoss()(img_embeds_origin, img_embeds)
            # calculate the token accuarcy
            # 从模型输出的logits中提取生成的token，用于计算生成准确率
            chosen_tokens = torch.max(outputs.logits, dim=-1)[1][:, 1:-1]    # [B, S-1]
            # print(self.llama_tokenizer.decode(chosen_tokens[0], skip_special_tokens=True))
            # 提取目标标签中的token，用于计算生成准确率
            labels = targets[:, 2:]
            # 计算生成准确率，通过比较生成的token与目标token来确定预测是否正确，并根据有效token计算准确率
            gen_acc = (chosen_tokens.reshape(-1) == labels.reshape(-1)).to(torch.long)    # [B*S]
            valid_mask = (labels != -100).reshape(-1)
            # print(self.llama_tokenizer.decode(chosen_tokens.reshape(-1)[valid_mask], skip_special_tokens=True))
            valid_tokens = gen_acc & valid_mask    # [B*S]
            gen_acc = valid_tokens.sum().item() / valid_mask.sum().item()

            return loss + loss_pixel, gen_acc
        
        else:
            
            image_paths = inputs['image_paths']
            img_embeds, _, patch_tokens = self.encode_image_from_tensor(image_paths)

            output_texts = inputs['output_texts']


            feats_text_tensor = encode_text_with_prompt_ensemble(self.visual_encoder, ['object'] * len(image_paths), self.device)

            anomaly_maps = []
            for layer in range(len(patch_tokens)):
                patch_tokens[layer] = patch_tokens[layer] / patch_tokens[layer].norm(dim=-1, keepdim=True)
                # print(patch_tokens[layer].shape)
                # anomaly_map = torch.bmm(patch_tokens[layer], feats_text_tensor.transpose(-2,-1))
                anomaly_map = (100.0 * patch_tokens[layer] @ feats_text_tensor.transpose(-2,-1))
                B, L, C = anomaly_map.shape
                H = int(np.sqrt(L))
                anomaly_map = F.interpolate(anomaly_map.permute(0, 2, 1).view(B, 2, H, H),
                                            size=224, mode='bilinear', align_corners=True)
                # anomaly_map_no_softmax = anomaly_map
                anomaly_map = torch.softmax(anomaly_map, dim=1)
                anomaly_maps.append(anomaly_map)

            for num in range(len(anomaly_maps)):
                anomaly_maps[num] = anomaly_maps[num][:,1,:,:]

            anomaly_map_all = torch.mean(torch.stack(anomaly_maps, dim=0), dim=0).unsqueeze(1)

            anomaly_map_prompts = self.prompt_learner(anomaly_map_all)

            # img_embeds = img_embeds + anomaly_map_prompts

            input_ids, target_ids, attention_mask = process_batch_instance(self.llama_tokenizer, output_texts, self.max_tgt_len)
            inputs_embeds, targets, attention_mask = self.prompt_wrap(img_embeds, input_ids, target_ids, attention_mask, anomaly_map_prompts)

            outputs = self.llama_model(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                return_dict=True,
                labels=targets,
            )
            loss = outputs.loss
            # calculate the token accuarcy
            chosen_tokens = torch.max(outputs.logits, dim=-1)[1][:, 1:-1]    # [B, S-1]
            labels = targets[:, 2:]
            gen_acc = (chosen_tokens.reshape(-1) == labels.reshape(-1)).to(torch.long)    # [B*S]
            valid_mask = (labels != -100).reshape(-1)
            valid_tokens = gen_acc & valid_mask    # [B*S]
            gen_acc = valid_tokens.sum().item() / valid_mask.sum().item()
            
            return loss, gen_acc


    def extract_multimodal_feature(self, inputs, web_demo):
        features = []
        if inputs['image_paths']:
            
            prompt = inputs['prompt']
            c_name = 'object'
            for name in CLASS_NAMES:
                if name in prompt:
                    c_name = name
                    break
                
            if not web_demo:
                image_embeds, _, patch_tokens = self.encode_image(inputs['image_paths'])
                feats_text_tensor = encode_text_with_prompt_ensemble(self.visual_encoder, [c_name], self.device)
            else:
                image_embeds, _, patch_tokens = self.encode_image_for_web_demo(inputs['image_paths'])
                feats_text_tensor = encode_text_with_prompt_ensemble(self.visual_encoder, [c_name], self.device)

            anomaly_maps = []
            for layer in range(len(patch_tokens)):
                patch_tokens[layer] = patch_tokens[layer] / patch_tokens[layer].norm(dim=-1, keepdim=True)
                # print(patch_tokens[layer].shape)
                # anomaly_map = torch.bmm(patch_tokens[layer], feats_text_tensor.transpose(-2,-1))
                anomaly_map = (100.0 * patch_tokens[layer] @ feats_text_tensor.transpose(-2,-1))
                B, L, C = anomaly_map.shape
                H = int(np.sqrt(L))
                anomaly_map = F.interpolate(anomaly_map.permute(0, 2, 1).view(B, 2, H, H),
                                            size=224, mode='bilinear', align_corners=True)
                anomaly_map = torch.softmax(anomaly_map, dim=1)
                anomaly_maps.append(anomaly_map[:,1,:,:])

            # 计算所有异常地图的平均值，并添加一个维度，使其形状为 (1, 1, 224, 224)。
            anomaly_map_ret = torch.mean(torch.stack(anomaly_maps, dim=0), dim=0).unsqueeze(1)
            # anomaly_map_all = anomaly_map_ret.unsqueeze(1).repeat((1,3,1,1))
            # anomaly_map_feature, _, _ = self.encode_image_from_tensor(anomaly_map_all)
            # image_embeds = anomaly_map_feature + image_embeds
            if inputs['normal_img_paths']:
                # 如果存在，计算异常地图与正常图像的相似度，并将其更新为 1 减去相似度。这样可以使异常地图的异常区域更加突出
                query_patch_tokens = self.encode_image_for_one_shot(inputs['image_paths'])
                if 'mvtec' in 'normal_img_paths':
                    normal_patch_tokens = self.encode_image_for_one_shot_with_aug(inputs['normal_img_paths'])
                else:
                    normal_patch_tokens = self.encode_image_for_one_shot(inputs['normal_img_paths'])
                sims = []

                for i in range(len(query_patch_tokens)):
                    query_patch_tokens_reshaped = query_patch_tokens[i].view(256,1,1280)
                    normal_tokens_reshaped = normal_patch_tokens[i].reshape(1,-1,1280)
                    cosine_similarity_matrix = F.cosine_similarity(query_patch_tokens_reshaped, normal_tokens_reshaped, dim=2)
                    sim_max, _ = torch.max(cosine_similarity_matrix, dim=1)
                    sims.append(sim_max)

                sim = torch.mean(torch.stack(sims,dim=0), dim=0).reshape(1,1,16,16)
                sim = F.interpolate(sim,size=224, mode='bilinear', align_corners=True)
                anomaly_map_ret = 1 - sim # (anomaly_map_ret + 1 - sim) / 2
                

            features.append(image_embeds)
        if inputs['audio_paths']:
            audio_embeds, _ = self.encode_audio(inputs['audio_paths'])
            features.append(audio_embeds)
        if inputs['video_paths']:
            video_embeds, _ = self.encode_video(inputs['video_paths'])
            features.append(video_embeds)
        if inputs['thermal_paths']:
            thermal_embeds, _ = self.encode_thermal(inputs['thermal_paths'])
            features.append(thermal_embeds)

        feature_embeds = torch.cat(features).sum(dim=0).unsqueeze(0)
        return feature_embeds, anomaly_map_ret

    def prepare_generation_embedding(self, inputs, web_demo):
        prompt = inputs['prompt']
        # if len(inputs['modality_embeds']) == 1:
        #     feature_embeds = inputs['modality_embeds'][0]
        # else:
        # 提取多模态特征
        feature_embeds, anomaly_map = self.extract_multimodal_feature(inputs, web_demo)
        # print(anomaly_map.shape)
        inputs['modality_embeds'].append(feature_embeds)

        batch_size = feature_embeds.shape[0]
        p_before = PROMPT_START
        p_before_tokens = self.llama_tokenizer(p_before, 
            return_tensors="pt", add_special_tokens=False).to(self.device)
        p_before_embeds = self.llama_model.model.model.embed_tokens(p_before_tokens.input_ids).expand(batch_size, -1, -1) # bsz x s1 x embed_dim
        
        p_middle = '</Img> '
        p_middle_tokens = self.llama_tokenizer(p_middle, 
            return_tensors="pt", add_special_tokens=False).to(self.device)
        # peft model need deeper call
        p_middle_embeds = self.llama_model.model.model.embed_tokens(p_middle_tokens.input_ids).expand(batch_size, -1, -1) # bsz x s1 x embed_dim

        # self.prompt_learner.eval()
        anomaly_map_prompts = self.prompt_learner(anomaly_map)




        text = prompt + '\n### Assistant:'
        p_after_tokens = self.llama_tokenizer(text, add_special_tokens=False, return_tensors='pt').to(self.device)
        p_after_embeds = self.llama_model.model.model.embed_tokens(p_after_tokens.input_ids).expand(batch_size, -1, -1) # bsz x s2 x embed_dim

        # 这段代码的目的是创建一个形状为 bsz x 1 x embed_dim 的 BOS 嵌入张量，用于在生成文本时作为输入的开始标记
        # * self.llama_tokenizer.bos_token_id：将上述创建的张量中的所有元素乘以 BOS 标记的索引值
        # 这是为了将全为1的张量转换为全为 BOS 标记的张量
        bos = torch.ones([batch_size, 1],
                         dtype=p_before_tokens.input_ids.dtype,
                         device=p_before_tokens.input_ids.device) * self.llama_tokenizer.bos_token_id # bsz x 1
        bos_embeds = self.llama_model.model.model.embed_tokens(bos)  # bsz x 1 x embed_dim
        inputs_embeds = torch.cat([bos_embeds, p_before_embeds, feature_embeds, p_middle_embeds, anomaly_map_prompts, p_after_embeds], dim=1) # bsz x (1+s1+1+s2) x embed_dim
    
        return inputs_embeds, anomaly_map

    def generate(self, inputs, web_demo=False):
        '''
            inputs = {
                'image_paths': optional,
                'audio_paths': optional
                'video_paths': optional
                'thermal_paths': optional
                'mode': generation mode,
                'prompt': human input prompt,
                'max_tgt_len': generation length,
                'top_p': top_p,
                'temperature': temperature
                'modality_embeds': None or torch.tensor
                'modality_cache': save the image cache
            }
        '''
        # self.prompt_learner.eval()
        # self.llama_model.eval()
        # self.llama_proj.eval()
        # self.image_decoder.eval()
        # self.llama_tokenizer.eval()
        input_embeds, pixel_output = self.prepare_generation_embedding(inputs, web_demo)
        stopping_criteria = StoppingCriteriaList([StoppingCriteriaSub(stops=[2277], encounters=1)])
        outputs = self.llama_model.generate(
            inputs_embeds=input_embeds,
            max_new_tokens=inputs['max_tgt_len'],
            top_p=inputs['top_p'],
            temperature=inputs['temperature'],
            do_sample=True,
            use_cache=True,
            stopping_criteria=stopping_criteria,
        )
        output_text = self.llama_tokenizer.decode(outputs[0][:-2], skip_special_tokens=True)
        return output_text, pixel_output