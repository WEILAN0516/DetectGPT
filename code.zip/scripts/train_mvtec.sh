#!/bin/bash
# master_port 指定主节点用于通信的端口号
# 表示用于多进程通信的端口号，通常情况下，不同的机器或者同一台机器上的不同GPU需要通过这个端口进行通信
deepspeed --include localhost:0,1 --master_port 28400 train_mvtec.py \
    --model openllama_peft \
    --stage 1\
    --imagebind_ckpt_path ../pretrained_ckpt/imagebind_ckpt/imagebind_huge.pth\
    --vicuna_ckpt_path ../pretrained_ckpt/vicuna_ckpt/7b_v0/\
    --delta_ckpt_path ../pretrained_ckpt/pandagpt_ckpt/7b/pytorch_model.pt\
    --max_tgt_len 1024\
    --data_path  ../data/pandagpt4_visual_instruction_data.json\
    --image_root_path ../data/images/\
    --save_path  ./ckpt/train_mvtec/\
    --log_path ./ckpt/train_mvtec/log_rest/